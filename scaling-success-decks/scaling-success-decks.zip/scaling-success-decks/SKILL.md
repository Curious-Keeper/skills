---
name: scaling-success-decks
description: Build a presentation deck in the Scaling Success house style as a polished, self-contained HTML file. Use whenever someone asks for a deck, slides, a talk, a presentation, or asks to change slides in one they already made, or asks to change its brand. Produces a single .html they download and present, with speaker notes and a presenter view.
---

# Building a deck

You are writing **content into a fixed structure**. You are not
designing slides. Layout, colors, type sizes, logo placement, the QR
code and slide order are owned by the renderer and cannot be set from
the deck file.

That constraint is the point. It is why two decks built a month apart
look like they came from the same business.

## First, check the runtime

This skill runs a Node build. Before anything else:

```bash
node --version
```

If that fails, stop and tell the user plainly: this skill needs code
execution turned on (Settings, then Capabilities) and cannot run
without it. Do not fall back to hand-writing HTML, and do not silently
produce something that skips validation. The validation IS the product.

## The workflow

1. **Read `engine/deck.schema.json`** (in this skill's folder). It is
   generated from `engine/spec.mjs` and is the exact shape you may
   produce, including every character budget as `maxLength`.
2. **Outline first** when the talk is longer than about 6 slides. One
   line per slide, shown to the user, before you write any JSON. Skip
   this only if they gave you the outline or asked for speed.
3. **Write `deck.json` to a writable working directory.** This skill's
   own folder is read only. Use the user's output directory, e.g.
   `/mnt/user-data/outputs/<slug>/deck.json`.
4. **Validate:**
   ```bash
   node <skill-dir>/engine/build.mjs /path/to/<slug>/deck.json --check
   ```
   Fix every error it reports. Repeat until clean.
5. **Build the file they get:**
   ```bash
   node <skill-dir>/engine/build.mjs /path/to/<slug>/deck.json --standalone
   ```
   That writes `<slug>.html` next to `deck.json`: one file, roughly
   300KB, with reveal.js and every image inlined. No network, no
   folder of assets.
6. **Hand it over.** Give them the file and tell them: open it in a
   browser, press **F** for fullscreen, **S** for the speaker view with
   your notes and a timer.

`reference/sample-deck.json` is a complete, valid deck. Read it to see
how the slide types fit together and how notes are written.

## The spine is fixed

`title` -> `promise` -> `roadmap` -> `slides[]` -> `contributions` ->
`final`. All five are required. You do not choose their order and you
cannot add another one.

- **`promise`** is what the audience can DO when they leave. Not a
  summary, not a restatement of the title. It addresses the room.
- **`contributions`** mirrors the promise. `gave` is what you covered,
  `can_now_do` is the promise delivered.
- **`final.words`** is a statement or a call to action tied back to the
  promise. Never a stock sign-off; validation rejects those.

## Choosing a body slide type

| Shape of the idea | Type |
|---|---|
| One big idea, stated plainly | `statement` (the default) |
| That idea plus one clarifying line | `statement` with `support` |
| An idea that needs a picture beside it | `split` |
| The picture IS the point | `visual` |
| Before/after, this-versus-that | `compare` |
| Someone else's words | `quote` |
| A number that lands | `metric` |
| Two or three ordered moves | `steps` |
| You stop and demo something | `demo` |
| The talk turns a corner | `section` |

Default to `statement`. A deck of mostly `statement` slides with a few
others is correct. A deck that rotates through every type to look
varied is worse, not better.

## Rules you cannot talk your way around

- **There is no `bullets` field.** One idea per slide means one
  `statement` per idea. Five points is five slides, or a `steps` slide
  capped at three, or it belongs in the speaker notes.
- **Character budgets are hard.** They are derived from the slide box
  and the fixed type size. When text overruns, shorten the text. Never
  ask to raise a budget and never shrink the type.
- **Every string is one line.** A slide that needs a second paragraph
  is a second slide.
- **Assets are local files that already exist.** Never invent an image
  path. If a slide wants a visual the user has not supplied, write the
  slide without one and tell them what image would help.
- **Alt text is mandatory** on every `visual`.
- **Branding is not yours to place.** There is no logo or QR field. The
  renderer puts the mark on every slide and the QR on the closing
  slide, from `brand/tokens.json`.
- **Never invent facts about the engagement.** `presenter` and
  `context` are the speaker's name and the venue/date. A prompt naming
  the AUDIENCE tells you who is in the room, not where the talk is.
  Omit either field when you were not told.

**A slide count in a request means BODY slides.** "A five slide deck"
gets five entries in `slides[]`, and the five spine slides bring the
total to ten. Say so when you report back.

## Speaker notes are the deliverable, not a bonus

Write `notes` on every slide. Notes are what appears in the presenter
view during the talk, so they are the delivery script: what to say,
where to pause, what to ask the room. They are not a summary of the
slide. The slide is already on the wall.

## Voice

<!-- voice:start -->
Informal but polished. Short sentences, short examples. Lead with actionable steps the room can use today.

On slides: one short line per idea, or a numbered list (a `steps` slide). Never bullets on a slide. Bullet points are fine in speaker notes.
<!-- voice:end -->

## When editing an existing deck

Change only what was asked. Do not rewrite slides that are working, do
not "improve" copy the user already approved, and do not reorder unless
asked. Rebuild with `--standalone` after.

# Rebranding this skill

When the user asks to put their own brand on this skill, you produce a
NEW skill zip for them to upload. You never edit this skill's folder;
it is read only.

## What you need from them

| Field | Required | Notes |
|---|---|---|
| `org` | yes | Business name as it should appear on slides. |
| `url` | yes | Their website, without `https://`. |
| `colors.accent` | yes | Their main brand color as `#rrggbb`. |
| `colors.night` | no | A dark brand color for title and closing slides. |
| `logo` | no | Path to an uploaded **single-color SVG**. |
| `qr` | no | Path to an uploaded QR image. Requires `qr_alt`. |
| `qr_alt` | with `qr` | Where the code goes, e.g. "QR code to book a call". |
| `qr_label` | no | A short line printed under the QR. |
| `voice` | no | Two to four sentences on how they talk. |

If they give you a website instead of colors, read the colors from it
and **show them the hex values you picked before building.** Do not
guess silently.

Uploaded files are under `/mnt/user-data/uploads/`. Check the paths
exist before you build.

**The logo must be a single-color SVG on a transparent background.**
The renderer recolors it for light and dark slides. A PNG, a
multi-color mark, or a mark on a white box is refused by the tool. When
that happens, tell them so in one sentence and offer the wordmark: the
business name set in the brand type, which is what the slides use when
`logo` is left out. Do not try to trace or redraw their logo.

**Typefaces are locked.** Every character budget is measured against
the fonts this skill ships. If they ask for their brand font, explain
that a different face would overrun the slides, and that fonts are a
later upgrade, not a workshop step. Do not put font fields in the
brand file; the tool refuses them.

## The steps

1. Write their answers to `/mnt/user-data/outputs/brand.json`:
   ```json
   {
     "org": "Acme Plumbing",
     "url": "acmeplumbing.com",
     "colors": { "accent": "#1f6fb2", "night": "#0f1d2b" },
     "logo": "/mnt/user-data/uploads/acme-logo.svg",
     "qr": "/mnt/user-data/uploads/qr.png",
     "qr_alt": "QR code to book a free estimate",
     "qr_label": "Book a free estimate",
     "voice": "Plain talk from a tradesman. No sales language."
   }
   ```
2. Run:
   ```bash
   node <skill-dir>/tools/rebrand.mjs /mnt/user-data/outputs/brand.json \
       --out /mnt/user-data/outputs
   ```
3. If it fails, read the message, fix the input, run it again. The
   messages say exactly what is wrong.
4. It writes `<name>.zip` and `<name>-preview.html`. Give them both.
5. Report every `adjusted:` line it prints. Those are brand colors that
   had to move to stay readable. They should know.
6. Tell them, in this order:
   - Open the preview in a browser and click through it.
   - Settings, then Capabilities, then Skills. Upload the zip.
   - Turn off or delete the `deck-starter` skill, so the two do not
     compete for the same requests.
   - Start a new chat and ask for a deck.
