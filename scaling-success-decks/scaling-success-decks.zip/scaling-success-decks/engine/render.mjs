/*
 * deck.json -> a self-contained reveal.js page.
 *
 * The renderer owns everything the deck does not: the stage size, the
 * type scale, the branding zone, the palette, and the reveal config.
 * A deck contributes text and asset paths. That split is why two decks
 * built a month apart look like the same practice.
 */

import { readFileSync, existsSync } from 'node:fs';
import { extname, join, relative } from 'node:path';
import { LAYOUTS, LOGO_SLIDES, NIGHT_SLIDES, esc } from './layouts.mjs';
import { auditPalette } from './contrast.mjs';
import { BODY, SPINE, SPINE_CLOSE, SPINE_ORDER } from './spec.mjs';

const ROOT = new URL('..', import.meta.url).pathname;
const MIME = {
	'.svg': 'image/svg+xml',
	'.png': 'image/png',
	'.jpg': 'image/jpeg',
	'.jpeg': 'image/jpeg',
	'.webp': 'image/webp',
};

/** Inline a small asset so the page survives file:// and PDF export. */
function dataUri(path) {
	if (!existsSync(path)) return null;
	const mime = MIME[extname(path).toLowerCase()];
	if (!mime) return null;
	return `data:${mime};base64,${readFileSync(path).toString('base64')}`;
}

/**
 * The logo ships as a single-color mark on a transparent ground, so the
 * renderer can tint it per surface instead of the brand folder carrying
 * one file per background.
 *
 * It is a swap of a NAMED color (`logo_source_color`), not "whatever
 * fill turns up first": if the artwork is ever replaced and that color
 * is not in it, the build stops rather than shipping an untinted mark
 * that happens to vanish into a night slide.
 */
function tintedLogo(svg, from, to, file) {
	const re = new RegExp(from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
	if (!re.test(svg)) {
		throw new Error(
			`brand/tokens.json says logo_source_color is "${from}", but ` +
				`brand/${file} does not contain it. Either retint the ` +
				'artwork or update logo_source_color to the color it uses.',
		);
	}
	const out = svg.replace(re, to);
	return `data:image/svg+xml;base64,${Buffer.from(out).toString('base64')}`;
}

export function loadBrand() {
	const dir = join(ROOT, 'brand');
	const brand = JSON.parse(readFileSync(join(dir, 'tokens.json'), 'utf8'));

	const failures = auditPalette(brand.palette);
	if (failures.length) {
		const lines = failures.map((f) => `  - ${f}`).join('\n');
		throw new Error(
			`brand/tokens.json fails WCAG AA contrast:\n${lines}\n` +
				'Fix the palette. A deck nobody at the back can read is not ' +
				'on brand.',
		);
	}

	/* Inlined so the closing slide and the mark survive with no network
	 * and no relative-path resolution, on any machine. */
	if (brand.logo_primary) {
		const file = join(dir, brand.logo_primary);
		if (!existsSync(file)) {
			throw new Error(
				`brand/tokens.json points at logo "${brand.logo_primary}" ` +
					'but the file is missing.',
			);
		}
		const svg = readFileSync(file, 'utf8');
		const from = brand.logo_source_color;
		if (!from) {
			throw new Error(
				'brand/tokens.json is missing "logo_source_color". The ' +
					'renderer tints the mark per surface and needs to know ' +
					'which color in the artwork to replace.',
			);
		}
		brand.logoDataUri = tintedLogo(svg, from, brand.palette.ink, brand.logo_primary);
		brand.logoNightDataUri = tintedLogo(
			svg,
			from,
			brand.palette.night_ink,
			brand.logo_primary,
		);
	} else {
		brand.logoDataUri = null;
		brand.logoNightDataUri = null;
	}

	brand.qrDataUri = brand.qr ? dataUri(join(dir, brand.qr)) : null;

	if (brand.qr && !brand.qrDataUri) {
		throw new Error(
			`brand/tokens.json points at qr "${brand.qr}" but brand/${brand.qr} ` +
				'is missing or not an image type the renderer can inline.',
		);
	}

	return brand;
}

/*
 * The stage. Declared once and used in three places: the reveal config,
 * the CSS that sizes a slide, and the character budgets in spec.mjs
 * that were derived from this box.
 */
export const STAGE = { width: 1280, height: 720 };

/*
 * Typefaces are inlined as base64 woff2, never linked.
 *
 * The rule that keeps images local applies harder to type: a remote
 * font that fails to arrive does not degrade the deck, it RESIZES it.
 * Every character budget in spec.mjs is derived from the advance width
 * of these two faces, so a venue with no wifi that silently fell back
 * to Georgia would reflow and overrun the slides the budgets exist to
 * protect. `font-display: block` for the same reason -- a flash of
 * fallback type mid-talk is a layout shift on a projector.
 */
function fontFaces(brand) {
	const dir = join(ROOT, 'brand');
	const faces = brand.fonts ?? [];
	if (!faces.length) {
		throw new Error(
			'brand/tokens.json declares no "fonts". The theme is sized to ' +
				'specific faces and will not render correctly without them.',
		);
	}

	return faces
		.map((f) => {
			const path = join(dir, f.file);
			if (!existsSync(path)) {
				throw new Error(
					`brand/tokens.json declares the font "${f.file}" but ` +
						'the file is missing. Fonts are embedded, not ' +
						'downloaded, so the build cannot continue without it.',
				);
			}
			const b64 = readFileSync(path).toString('base64');
			const fmt = f.variable ? 'woff2-variations' : 'woff2';
			return `\t@font-face {
		font-family: '${f.family}';
		font-style: ${f.style};
		font-weight: ${f.weight};
		font-display: block;
		src: url(data:font/woff2;base64,${b64}) format('${fmt}');
	}`;
		})
		.join('\n');
}

/** brand palette -> CSS custom properties. The only color entry point. */
function paletteVars(brand) {
	const roles = Object.entries(brand.palette)
		.map(([k, v]) => `\t\t--${k.replace(/_/g, '-')}: ${v};`)
		.join('\n');
	return `\t:root {\n${roles}
		--typeface-heading: ${brand.typeface_heading};
		--typeface-body: ${brand.typeface_body};
		--stage-w: ${STAGE.width}px;
		--stage-h: ${STAGE.height}px;
	}`;
}

/** Wrap one slide's inner HTML in its <section>, with notes and mark. */
function wrapSlide(kind, inner, notes, brand) {
	const isLogo = LOGO_SLIDES.has(kind);
	const brandAttr = isLogo ? ' data-brand="logo"' : '';

	/*
	 * The surface is a property of the SLIDE TYPE, not of the deck. A
	 * deck cannot choose which slides invert, for the same reason it
	 * cannot choose a color: the alternation between night and paper
	 * is the brand's rhythm, so it has to be the same in every deck.
	 */
	const surfaceAttr = NIGHT_SLIDES.has(kind) ? ' data-surface="night"' : '';

	const zone = isLogo
		? ''
		: `<div class="brand-zone" aria-hidden="true">
	<span class="brand-zone__mark">${esc(brand.org_display_name)}</span>
	<span>${esc(brand.url)}</span>
</div>`;

	const aside = notes
		? `<aside class="notes">${esc(notes).replace(/\n/g, '<br>')}</aside>`
		: '';

	/*
	 * The layout box is an inner div, NOT the section.
	 *
	 * Reveal owns `display` on sections to show and hide them, and its
	 * `.reveal .slides>section.present{display:block}` outranks any
	 * plain descendant selector a theme can write. Putting flex on the
	 * section loses that fight silently and pins every slide to the top
	 * of the stage. Nothing in reveal targets .slide-body.
	 */
	return `<section class="l-${kind}"${brandAttr}${surfaceAttr}>
<div class="slide-body">
${inner}
</div>
${zone}
${aside}
</section>`;
}

function renderSlide(kind, data, brand) {
	const emit = LAYOUTS[kind];
	if (!emit) throw new Error(`no layout for slide type "${kind}"`);
	const ctx = { night: NIGHT_SLIDES.has(kind) };
	return wrapSlide(kind, emit(data, brand, ctx), data.notes, brand);
}

/*
 * Deck asset paths are written relative to the DECK FOLDER, because
 * that is what makes sense to a person editing deck.json. The page
 * cannot use them as-is: it is served at / by the dev server and sits
 * at decks/<slug>/index.html on disk, so a bare `assets/x.png` resolves
 * to two different places.
 *
 * Rewriting to `../../decks/<slug>/assets/x.png` works from BOTH, for
 * the same reason the vendor paths do: from the built file it walks up
 * to the repo root, and from / the browser clamps at the root.
 *
 * Which fields are assets comes from the spec, so a new asset field on
 * a new slide type is handled without touching this function.
 */
function resolveAssets(kind, data, { base, deckDir, standalone }) {
	const fields = (SPINE[kind] ?? BODY[kind])?.fields ?? {};
	const out = { ...data };
	for (const [name, field] of Object.entries(fields)) {
		if (field.kind !== 'asset' || typeof out[name] !== 'string') continue;

		if (!standalone) {
			out[name] = `${base}/${out[name]}`;
			continue;
		}

		/* Standalone carries its images inside the file. Validation has
		 * already proven the path exists, so a failure here is an image
		 * type the renderer cannot inline, not a missing file. */
		const uri = dataUri(join(deckDir, out[name]));
		if (!uri) {
			throw new Error(
				`cannot inline ${out[name]} for a standalone build. ` +
					'Supported: svg, png, jpg, webp.',
			);
		}
		out[name] = uri;
	}
	return out;
}

/*
 * reveal, as files to link or as source to inline.
 *
 * No highlight plugin: it is 899KB and the deck schema has no field
 * that can hold a code block, so it could only ever be dead weight.
 */
const VENDOR_CSS = ['reset.css', 'reveal.css'];
const VENDOR_JS = ['reveal.js', 'plugin/notes.js', 'plugin/zoom.js', 'plugin/search.js'];

const vendorFile = (p) => readFileSync(join(ROOT, 'vendor', 'reveal', p), 'utf8');

/** The ordered list of [kind, data] pairs a deck renders to. */
export function slideSequence(deck) {
	return [
		...SPINE_ORDER.map((k) => [k, deck[k]]),
		...deck.slides.map((s) => {
			const { type, ...rest } = s;
			return [type, rest];
		}),
		...SPINE_CLOSE.map((k) => [k, deck[k]]),
	];
}

const REVEAL_CONFIG = `{
	width: ${STAGE.width},
	height: ${STAGE.height},
	margin: 0,
	minScale: 0.2,
	maxScale: 2.0,
	controls: false,
	progress: true,
	slideNumber: 'c/t',
	hash: true,
	history: false,
	center: false,
	transition: 'fade',
	transitionSpeed: 'fast',
	backgroundTransition: 'none',
	pdfSeparateFragments: false,
	plugins: [RevealNotes, RevealZoom, RevealSearch],
}`;

export function renderDeck(deck, brand, opts = {}) {
	const { live = false, standalone = false, deckDir = null } = opts;
	const theme = readFileSync(join(ROOT, 'engine', 'theme.css'), 'utf8');

	/*
	 * `../../<path>` works from BOTH the built file (walks up to the
	 * repo root) and the dev server (the browser clamps at /).
	 */
	const rel = deckDir ? relative(ROOT, deckDir) : `decks/${deck.slug}`;
	if (!standalone && rel.startsWith('..')) {
		throw new Error(
			`the deck lives outside the project (${rel}), so its assets ` +
				'cannot be linked. Build it with --standalone to inline them.',
		);
	}
	const base = `../../${rel}`;

	const sections = slideSequence(deck)
		.map(([kind, data]) =>
			renderSlide(kind, resolveAssets(kind, data, { base, deckDir, standalone }), brand),
		)
		.join('\n\n');

	const styles = standalone
		? `<style>\n${VENDOR_CSS.map(vendorFile).join('\n')}\n</style>`
		: VENDOR_CSS.map(
				(f) => `<link rel="stylesheet" href="../../vendor/reveal/${f}">`,
			).join('\n');

	const scripts = standalone
		? `<script>\n${VENDOR_JS.map(vendorFile)
				.join('\n;\n')
				.replace(/<\/script/gi, '<\\/script')}\n</script>`
		: VENDOR_JS.map(
				(f) => `<script src="../../vendor/reveal/${f}"></script>`,
			).join('\n');

	const reload = live
		? `<script>
	new EventSource('/__reload').onmessage = () => location.reload();
</script>`
		: '';

	return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(deck.title.title)} — ${esc(brand.org_display_name)}</title>
${styles}
<style>
${fontFaces(brand)}

${paletteVars(brand)}

${theme}
</style>
</head>
<body>
<div class="reveal">
<div class="slides">

${sections}

</div>
</div>
${scripts}
<script>
	Reveal.initialize(${REVEAL_CONFIG});

	/*
	 * Publish the current slide's surface on the root element.
	 *
	 * Two things outside the slide need it. The stage is a fixed
	 * 1280x720 box scaled to fit, so any window that is not 16:9 -- a
	 * laptop preview, a windowed projector, the speaker view -- gets
	 * letterbox bars painted by .reveal-viewport, and a night slide
	 * left alone shows up framed in paper. The progress bar and slide
	 * number have the same problem for the same reason: they are
	 * siblings of .slides, so the theme's night block cannot reach
	 * them. theme.css keys all of it off this one attribute.
	 */
	(function syncSurface() {
		function apply() {
			var slide = Reveal.getCurrentSlide();
			var night = slide && slide.dataset.surface === 'night';
			document.documentElement.dataset.surface = night
				? 'night'
				: 'paper';
		}
		Reveal.on('ready', apply);
		Reveal.on('slidechanged', apply);
		apply();
	})();
</script>
${reload}
</body>
</html>
`;
}
