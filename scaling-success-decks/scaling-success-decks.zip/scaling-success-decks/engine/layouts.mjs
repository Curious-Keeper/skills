/*
 * Layouts. One emitter per slide type, and this is the ONLY place deck
 * data becomes HTML.
 *
 * Every emitter returns the inner HTML of a <section>. The branding
 * zone, section attributes and speaker notes are added by render.mjs,
 * so a layout cannot forget the mark or style around it.
 *
 * All deck strings pass through `esc` before reaching the page, then
 * through `inline` which re-admits exactly three marks: **bold**,
 * *italic* and `code`. There is deliberately no way to inject a tag,
 * a class or a style from deck.json.
 */

const esc = (s) =>
	String(s)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;');

/** Escape first, then allow the three inline marks. */
export function inline(s) {
	return esc(s)
		.replace(/`([^`]+)`/g, '<code>$1</code>')
		.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
		.replace(/\*([^*]+)\*/g, '<em>$1</em>');
}

/** An <img> for an asset path, always with alt text. */
const img = (cls, src, alt) =>
	`<img class="${cls}" src="${esc(src)}" alt="${esc(alt ?? '')}">`;

/** Emit `html` only when `value` is set. Keeps the emitters flat. */
const when = (value, html) => (value ? html : '');

/* -------------------------------------------------------------------
 * Spine
 * ----------------------------------------------------------------- */

export function title(s, brand, ctx = {}) {
	const logo = ctx.night ? brand.logoNightDataUri : brand.logoDataUri;
	const mark = logo
		? `<img class="l-title__logo" src="${logo}" alt="${esc(
				brand.logo_alt,
			)}">`
		: `<div class="l-title__wordmark">${esc(brand.org_display_name)}</div>`;

	const meta = [s.presenter, s.context]
		.filter(Boolean)
		.map((v) => `<span>${inline(v)}</span>`)
		.join('');

	return `${mark}
<h1 class="l-title__title">${inline(s.title)}</h1>
${when(s.subtitle, `<p class="l-title__subtitle">${inline(s.subtitle ?? '')}</p>`)}
${when(meta, `<div class="l-title__meta">${meta}</div>`)}`;
}

export function promise(s) {
	return `<p class="l-promise__kicker">${inline(s.kicker ?? 'What you leave with')}</p>
<p class="l-promise__text">${inline(s.promise)}</p>`;
}

export function roadmap(s) {
	const stops = s.stops
		.map(
			(stop, i) =>
				`<li class="l-roadmap__stop"><span class="l-roadmap__n">${
					i + 1
				}</span><span>${inline(stop)}</span></li>`,
		)
		.join('\n');

	return `<h2 class="l-roadmap__label">${inline(s.label ?? 'Where we are going')}</h2>
<ol class="l-roadmap__stops">${stops}</ol>`;
}

export function contributions(s) {
	const col = (head, items) =>
		`<div><p class="l-contrib__head">${head}</p><ul class="l-contrib__list">${items
			.map((i) => `<li>${inline(i)}</li>`)
			.join('')}</ul></div>`;

	return `<div class="l-contrib__cols">
${col('What you got', s.gave)}
${col('What you can now do', s.can_now_do)}
</div>`;
}

/*
 * The QR comes from BRAND, not from the deck, so every deck closes the
 * same way and none of them can forget it or move it.
 */
export function final(s, brand) {
	const qr = brand.qrDataUri
		? `<div class="l-final__qr-block">
<img class="l-final__qr" src="${brand.qrDataUri}" alt="${esc(brand.qr_alt ?? '')}">
${when(brand.qr_label, `<p class="l-final__qr-label">${esc(brand.qr_label)}</p>`)}
</div>`
		: '';

	return `<div class="l-final__text">
<p class="l-final__words">${inline(s.words)}</p>
${when(s.cta, `<div class="l-final__cta">${inline(s.cta ?? '')}</div>`)}
</div>
${qr}`;
}

/* -------------------------------------------------------------------
 * Body
 * ----------------------------------------------------------------- */

export function statement(s) {
	return `<div class="rule"></div>
<p class="l-statement__idea">${inline(s.idea)}</p>
${when(s.support, `<p class="l-statement__support">${inline(s.support ?? '')}</p>`)}
${when(s.visual, img('l-statement__visual', s.visual, s.visual_alt))}`;
}

export function split(s) {
	return `<div>
<p class="l-split__idea">${inline(s.idea)}</p>
${when(s.support, `<p class="l-split__support">${inline(s.support ?? '')}</p>`)}
</div>
${img('l-split__visual', s.visual, s.visual_alt)}`;
}

export function visual(s) {
	return `${img('l-visual__img', s.visual, s.visual_alt)}
${when(s.caption, `<p class="l-visual__caption">${inline(s.caption ?? '')}</p>`)}`;
}

export function compare(s) {
	const p = (side, data) =>
		`<div class="l-compare__panel l-compare__panel--${side}">
${when(
	data.label,
	`<p class="l-compare__panel-label">${inline(data.label ?? '')}</p>`,
)}
<p class="l-compare__panel-idea">${inline(data.idea)}</p>
</div>`;

	return `${when(s.label, `<p class="l-compare__label">${inline(s.label ?? '')}</p>`)}
<div class="l-compare__panels">${p('left', s.left)}${p('right', s.right)}</div>`;
}

export function quote(s) {
	return `<p class="l-quote__text">&ldquo;${inline(s.quote)}&rdquo;</p>
${when(s.attribution, `<p class="l-quote__attr">${inline(s.attribution ?? '')}</p>`)}`;
}

export function metric(s) {
	return `<p class="l-metric__value">${inline(s.value)}</p>
<p class="l-metric__label">${inline(s.label)}</p>
${when(s.context, `<p class="l-metric__context">${inline(s.context ?? '')}</p>`)}`;
}

export function steps(s) {
	const items = s.steps
		.map(
			(step, i) =>
				`<li class="l-steps__item"><span class="l-steps__n">${
					i + 1
				}</span><span>${inline(step)}</span></li>`,
		)
		.join('\n');

	return `${when(s.label, `<p class="l-steps__label">${inline(s.label ?? '')}</p>`)}
<ol class="l-steps__list">${items}</ol>`;
}

export function demo(s) {
	return `<div class="l-demo__badge">Live</div>
<p class="l-demo__label">${inline(s.label)}</p>
${when(s.detail, `<p class="l-demo__detail">${inline(s.detail ?? '')}</p>`)}
${when(s.visual, img('l-demo__visual', s.visual, s.visual_alt))}`;
}

export function section(s) {
	return `<p class="l-section__kicker">Next</p>
<p class="l-section__label">${inline(s.label)}</p>
${when(s.sub, `<p class="l-section__sub">${inline(s.sub ?? '')}</p>`)}`;
}

export const LAYOUTS = {
	title,
	promise,
	roadmap,
	contributions,
	final,
	statement,
	split,
	visual,
	compare,
	quote,
	metric,
	steps,
	demo,
	section,
};

/** Slides that carry the full logo instead of the small mark. */
export const LOGO_SLIDES = new Set(['title', 'final']);

/*
 * Slides that render on the dark surface.
 *
 * The site alternates dark bands (the hero, the closing CTA) against
 * paper, and the deck reads as the same practice by doing the same
 * thing: the talk OPENS dark, each section divider drops back to dark
 * to mark the turn, and it CLOSES dark. Everything in between is paper.
 *
 * This is a renderer decision, not a deck field, so no deck can invert
 * a slide that should be paper or vice versa.
 */
export const NIGHT_SLIDES = new Set(['title', 'section', 'final']);

export { esc };
