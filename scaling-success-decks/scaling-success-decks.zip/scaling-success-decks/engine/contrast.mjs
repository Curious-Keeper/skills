/*
 * WCAG 2.1 relative luminance and contrast ratio.
 *
 * The palette is checked when the BRAND is built, not when a slide is
 * rendered, because a palette is chosen once and then used by every
 * deck. A role pair that fails AA fails the build with the measured
 * ratio and the required one, the same way any other rule reports.
 */

/** #rgb or #rrggbb -> [r, g, b] in 0..255. Throws on anything else. */
export function parseHex(hex) {
	const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex).trim());
	if (!m) throw new Error(`not a hex color: ${hex}`);
	const h =
		m[1].length === 3
			? m[1]
					.split('')
					.map((c) => c + c)
					.join('')
			: m[1];
	return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
}

function channel(v) {
	const s = v / 255;
	return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

export function luminance(hex) {
	const [r, g, b] = parseHex(hex).map(channel);
	return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** Contrast ratio between two hex colors, 1..21. */
export function ratio(a, b) {
	const [x, y] = [luminance(a), luminance(b)].sort((m, n) => n - m);
	return (x + 0.05) / (y + 0.05);
}

/*
 * Every foreground/background pair the layouts can request. A template
 * asks for a ROLE PAIR; it cannot invent a combination that was never
 * checked. Large-text pairs are held to AA large (3.0) and body pairs
 * to AA (4.5) -- the branding zone is small text and gets 4.5, because
 * a recessive mark that fails AA is not a saving.
 */
export const REQUIRED_PAIRS = [
	['ink', 'surface', 4.5, 'body text'],
	['muted', 'surface', 4.5, 'supporting text'],
	['accent', 'surface', 4.5, 'accent text and rules'],
	['accent_ink', 'accent', 4.5, 'text on an accent fill'],
	['branding_zone_ink', 'surface', 4.5, 'the branding zone'],
	['ink', 'panel', 4.5, 'text inside a compare panel'],

	/*
	 * The night surface. Title, section and final slides invert, the
	 * same way the site alternates its dark bands against paper. A
	 * second surface is a second set of pairs: without these, half the
	 * deck would render on a background nothing had ever measured.
	 *
	 * `accent` is a rust dark enough to read on paper, which is exactly
	 * what makes it illegible on night, so night gets its own lighter
	 * accent rather than reusing one that would fail here.
	 */
	['night_ink', 'night', 4.5, 'body text on a night slide'],
	['night_muted', 'night', 4.5, 'supporting text on a night slide'],
	['night_accent', 'night', 4.5, 'accent text and rules on a night slide'],
	['night', 'night_accent', 4.5, 'text on a night accent fill'],
];

/**
 * Check a palette. Returns a list of failure strings, empty if it passes.
 */
export function auditPalette(palette) {
	const failures = [];
	for (const [fg, bg, min, use] of REQUIRED_PAIRS) {
		if (!palette[fg]) {
			failures.push(`palette is missing the "${fg}" role`);
			continue;
		}
		if (!palette[bg]) {
			failures.push(`palette is missing the "${bg}" role`);
			continue;
		}
		const r = ratio(palette[fg], palette[bg]);
		if (r < min) {
			failures.push(
				`${fg} (${palette[fg]}) on ${bg} (${palette[bg]}) is ` +
					`${r.toFixed(2)}:1, needs ${min}:1 for ${use}`,
			);
		}
	}
	return failures;
}
