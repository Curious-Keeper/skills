/*
 * Deck validation. Every failure is reported with the slide it came
 * from, the field, and the number that was missed -- never "invalid
 * deck". A build that fails here has NOT written an HTML file, so there
 * is no such thing as a half-correct deck sitting on disk waiting to be
 * projected.
 */

import { existsSync } from 'node:fs';
import { join } from 'node:path';
import {
	BODY,
	BODY_TYPES,
	FORBIDDEN_FINAL_WORDS,
	SPINE,
	UNIVERSAL_FIELDS,
} from './spec.mjs';

/** Inline marks the renderer understands; they do not count as content. */
const MARKS = /\*\*|\*|`/g;

const visibleLength = (s) => s.replace(MARKS, '').length;

class Report {
	constructor() {
		this.errors = [];
	}
	at(where, message) {
		this.errors.push(`${where}: ${message}`);
	}
	get ok() {
		return this.errors.length === 0;
	}
}

function checkField(report, where, name, value, field, deckDir) {
	const path = `${where}.${name}`;

	switch (field.kind) {
		case 'notes':
			if (typeof value !== 'string') {
				report.at(path, 'speaker notes must be a string');
			}
			return;

		case 'text': {
			if (typeof value !== 'string' || value.trim() === '') {
				report.at(path, 'must be a non-empty string');
				return;
			}
			if (value.includes('\n')) {
				report.at(
					path,
					'must be a single line. A slide that needs a second ' +
						'paragraph is a second slide.',
				);
			}
			const n = visibleLength(value);
			if (n > field.max) {
				report.at(
					path,
					`is ${n} characters, the budget is ${field.max}. ` +
						'The type size is fixed, so this has to get shorter.',
				);
			}
			return;
		}

		case 'asset': {
			if (typeof value !== 'string' || value.trim() === '') {
				report.at(path, 'must be a path to a file');
				return;
			}
			if (/^https?:/i.test(value)) {
				report.at(
					path,
					'must be a local file. A remote image is a venue wifi ' +
						'outage waiting to happen.',
				);
				return;
			}
			if (!existsSync(join(deckDir, value))) {
				report.at(path, `file not found: ${value}`);
			}
			return;
		}

		case 'list': {
			if (!Array.isArray(value)) {
				report.at(path, 'must be a list');
				return;
			}
			if (value.length < field.min || value.length > field.max) {
				report.at(
					path,
					`has ${value.length} entries, allowed range is ` +
						`${field.min} to ${field.max}`,
				);
			}
			value.forEach((entry, i) => {
				checkField(report, path, `[${i}]`, entry, field.item, deckDir);
			});
			return;
		}

		case 'panel': {
			if (typeof value !== 'object' || value === null) {
				report.at(path, 'must be an object');
				return;
			}
			checkShape(report, path, value, field.fields, [], deckDir);
			return;
		}

		default:
			report.at(path, `unknown field kind: ${field.kind}`);
	}
}

/**
 * Check one object against a field table. Unknown keys are errors --
 * this is what stops a deck from carrying styling, colors, or a
 * `bullets` field the renderer would silently drop on the floor.
 */
function checkShape(report, where, obj, fields, required, deckDir) {
	const allowed = { ...fields, ...UNIVERSAL_FIELDS };

	for (const key of Object.keys(obj)) {
		if (!(key in allowed)) {
			const hint =
				key === 'bullets'
					? '. There is no bullets field. Use one `statement` ' +
						'slide per idea, or a `steps` slide capped at three.'
					: `. Allowed here: ${Object.keys(allowed).join(', ')}`;
			report.at(where, `unknown field "${key}"${hint}`);
		}
	}

	for (const key of required) {
		if (!(key in obj)) report.at(where, `missing required field "${key}"`);
	}

	for (const [key, value] of Object.entries(obj)) {
		if (key in allowed) {
			checkField(report, where, key, value, allowed[key], deckDir);
		}
	}
}

function checkSpine(report, deck, deckDir) {
	for (const [name, def] of Object.entries(SPINE)) {
		const slide = deck[name];
		if (typeof slide !== 'object' || slide === null) {
			report.at(
				`deck.${name}`,
				`is required. Every deck opens with title, promise and ` +
					`roadmap, and closes with contributions and final.`,
			);
			continue;
		}
		checkShape(report, `deck.${name}`, slide, def.fields, def.required, deckDir);
	}
}

/** Winston §5: never end on a stock sign-off. */
function checkFinalWords(report, deck) {
	const words = deck.final?.words;
	if (typeof words !== 'string') return;
	const normalized = words.toLowerCase().replace(/[.!?]+$/g, '').trim();
	for (const banned of FORBIDDEN_FINAL_WORDS) {
		if (normalized === banned || normalized.endsWith(` ${banned}`)) {
			report.at(
				'deck.final.words',
				`ends on "${banned}". Close on a statement or a call to ` +
					'action tied back to the promise.',
			);
		}
	}
}

function checkBody(report, deck, deckDir) {
	if (!Array.isArray(deck.slides) || deck.slides.length === 0) {
		report.at('deck.slides', 'must be a non-empty list of body slides');
		return;
	}

	deck.slides.forEach((slide, i) => {
		const where = `deck.slides[${i}]`;
		if (typeof slide !== 'object' || slide === null) {
			report.at(where, 'must be an object');
			return;
		}
		const def = BODY[slide.type];
		if (!def) {
			report.at(
				where,
				`unknown slide type "${slide.type}". One of: ` +
					BODY_TYPES.join(', '),
			);
			return;
		}
		const { type, ...rest } = slide;
		checkShape(report, `${where} (${type})`, rest, def.fields, def.required, deckDir);

		/* Only for types where the visual is OPTIONAL; where it is
		 * required, the missing-field check above already said so. */
		if (!def.required.includes('visual_alt') && rest.visual && !rest.visual_alt) {
			report.at(
				`${where} (${type})`,
				'has a visual but no visual_alt. Alt text is not optional.',
			);
		}
	});
}

/**
 * Validate a parsed deck. Returns { ok, errors }.
 * `deckDir` is the folder deck.json lives in; asset paths resolve
 * against it.
 */
export function validateDeck(deck, deckDir) {
	const report = new Report();

	if (typeof deck !== 'object' || deck === null) {
		report.at('deck', 'must be a JSON object');
		return report;
	}

	const META = ['$schema', 'slug', 'title', 'promise', 'roadmap', 'slides',
		'contributions', 'final'];
	for (const key of Object.keys(deck)) {
		if (!META.includes(key)) {
			report.at('deck', `unknown top-level field "${key}"`);
		}
	}

	checkSpine(report, deck, deckDir);
	checkBody(report, deck, deckDir);
	checkFinalWords(report, deck);

	return report;
}
