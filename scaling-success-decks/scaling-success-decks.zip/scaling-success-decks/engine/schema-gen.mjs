/*
 * Generate engine/deck.schema.json from spec.mjs.
 *
 * The schema is not a second source of truth -- it is compiled output.
 * It exists so an editor autocompletes deck.json and so a model can be
 * handed the exact shape it is allowed to produce. Regenerate with
 * `./deck schema` after changing spec.mjs.
 */

import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { BODY, SPINE, UNIVERSAL_FIELDS } from './spec.mjs';

const ROOT = new URL('..', import.meta.url).pathname;

function fieldSchema(field) {
	switch (field.kind) {
		case 'notes':
			return {
				type: 'string',
				description: 'Speaker notes. Never rendered onto the slide.',
			};
		case 'text':
			return {
				type: 'string',
				minLength: 1,
				maxLength: field.max,
				...(field.doc ? { description: field.doc } : {}),
			};
		case 'asset':
			return {
				type: 'string',
				minLength: 1,
				description: 'Path to a local file, relative to the deck folder.',
			};
		case 'list':
			return {
				type: 'array',
				minItems: field.min,
				maxItems: field.max,
				items: fieldSchema(field.item),
			};
		case 'panel':
			return objectSchema(field.fields, Object.keys(field.fields));
		default:
			throw new Error(`unknown kind ${field.kind}`);
	}
}

function objectSchema(fields, required, extra = {}) {
	const properties = { ...extra };
	for (const [name, field] of Object.entries(fields)) {
		properties[name] = fieldSchema(field);
	}
	return {
		type: 'object',
		additionalProperties: false,
		required,
		properties,
	};
}

const spine = {};
for (const [name, def] of Object.entries(SPINE)) {
	spine[name] = {
		...objectSchema({ ...def.fields, ...UNIVERSAL_FIELDS }, def.required),
		description: def.doc,
	};
}

const body = Object.entries(BODY).map(([type, def]) => ({
	...objectSchema({ ...def.fields, ...UNIVERSAL_FIELDS }, ['type', ...def.required], {
		type: { const: type },
	}),
	title: type,
	description: def.doc,
}));

const schema = {
	$schema: 'https://json-schema.org/draft/2020-12/schema',
	title: 'Deck',
	description:
		'A presentation. The spine (title, promise, roadmap, contributions, ' +
		'final) is fixed; only `slides` varies. There is no bullets field ' +
		'and no styling field anywhere in this schema, by design.',
	type: 'object',
	additionalProperties: false,
	required: ['slug', 'title', 'promise', 'roadmap', 'slides', 'contributions', 'final'],
	properties: {
		$schema: { type: 'string' },
		slug: { type: 'string', pattern: '^[a-z0-9-]+$' },
		...spine,
		slides: {
			type: 'array',
			minItems: 1,
			description: 'The body of the talk, in order.',
			items: { oneOf: body },
		},
	},
};

const out = join(ROOT, 'engine', 'deck.schema.json');
writeFileSync(out, `${JSON.stringify(schema, null, 2)}\n`);
console.log(`✓ engine/deck.schema.json (${body.length} body slide types)`);
