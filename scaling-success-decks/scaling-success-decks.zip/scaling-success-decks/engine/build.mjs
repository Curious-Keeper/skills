/*
 * Build one deck. Validate, then render.
 *
 * A deck that fails validation does NOT write index.html. There is no
 * such thing as a partly-correct deck sitting on disk waiting to be
 * projected in front of a room.
 */

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { validateDeck } from './validate.mjs';
import { loadBrand, renderDeck, slideSequence } from './render.mjs';

const ROOT = new URL('..', import.meta.url).pathname;

/*
 * A deck is addressed EITHER by slug (decks/<slug>/deck.json) or by a
 * path to a folder or a deck.json anywhere on disk.
 *
 * The path form exists because the engine also ships as a Claude skill,
 * where the skill directory is read-only and the deck has to be written
 * somewhere else entirely.
 */
export function resolveDeck(arg) {
	const looksLikePath = arg.endsWith('.json') || arg.includes('/');
	const file = looksLikePath
		? resolve(arg.endsWith('.json') ? arg : join(arg, 'deck.json'))
		: join(ROOT, 'decks', arg, 'deck.json');
	const dir = dirname(file);
	return { file, dir, slug: looksLikePath ? basename(dir) : arg };
}

export const deckDir = (slug) => resolveDeck(slug).dir;

export function readDeck(target) {
	const { file } = typeof target === 'string' ? resolveDeck(target) : target;
	if (!existsSync(file)) throw new Error(`no deck at ${file}`);
	try {
		return JSON.parse(readFileSync(file, 'utf8'));
	} catch (e) {
		throw new Error(`${file} is not valid JSON: ${e.message}`);
	}
}

/**
 * Validate and render. Returns { html, slideCount, notesCount }.
 * Throws a formatted error listing every violation.
 */
/*
 * Validate only. Deliberately does NOT render.
 *
 * Rendering needs to know where the page will sit so it can resolve
 * asset paths, and that has nothing to do with whether the deck is
 * correct. Folding the two together made `--check` fail on any deck
 * outside the project with an error about linking assets, which is the
 * first command the skill runs.
 */
export function checkDeck(arg) {
	const target = resolveDeck(arg);
	const deck = readDeck(target);
	const report = validateDeck(deck, target.dir);

	if (!report.ok) {
		const lines = report.errors.map((e) => `  ✗ ${e}`).join('\n');
		throw new Error(
			`${target.file} has ${report.errors.length} problem` +
				`${report.errors.length === 1 ? '' : 's'}:\n${lines}`,
		);
	}

	const sequence = slideSequence(deck);
	return {
		deck,
		target,
		slideCount: sequence.length,
		notesCount: sequence.filter(([, d]) => d.notes?.trim()).length,
	};
}

export function buildDeck(arg, { live = false, standalone = false } = {}) {
	const { deck, target, slideCount, notesCount } = checkDeck(arg);
	const brand = loadBrand();
	return {
		html: renderDeck(deck, brand, { live, standalone, deckDir: target.dir }),
		slideCount,
		notesCount,
		target,
	};
}

export function writeDeck(arg, opts = {}) {
	const built = buildDeck(arg, opts);
	/* Standalone gets its own name: it is the file you hand to someone
	 * else, and it must not overwrite the one the dev server rebuilds. */
	const name = opts.standalone ? `${built.target.slug}.html` : 'index.html';
	const out = join(built.target.dir, name);
	writeFileSync(out, built.html);
	return { ...built, out };
}

/*
 * A 30-minute slot is the real constraint, so the build reports pace
 * rather than leaving it to be discovered on stage.
 */
function pacing(slideCount) {
	const low = (slideCount * 0.75).toFixed(0);
	const high = (slideCount * 1.5).toFixed(0);
	return `roughly ${low}-${high} min at 45-90 s a slide`;
}

if (import.meta.url === `file://${process.argv[1]}`) {
	const arg = process.argv[2];
	const check = process.argv.includes('--check');
	const standalone = process.argv.includes('--standalone');

	if (!arg || arg.startsWith('--')) {
		console.error(
			'usage: node engine/build.mjs <slug|path> [--check] [--standalone]',
		);
		process.exit(2);
	}

	try {
		const built = check ? checkDeck(arg) : writeDeck(arg, { standalone });
		const where = check
			? '(checked, not written)'
			: `${built.out}${standalone ? `  ${(built.html.length / 1024).toFixed(0)} KB, self-contained` : ''}`;
		console.log(
			`✓ ${built.target.slug}: ${built.slideCount} slides, ` +
				`${built.notesCount} with notes, ${pacing(built.slideCount)}\n  ${where}`,
		);
	} catch (e) {
		console.error(`\n${e.message}\n`);
		process.exit(1);
	}
}
