/*
 * THE SLIDE SPEC. Single source of truth.
 *
 * `validate.mjs`, `schema-gen.mjs` and `layouts.mjs` all read this file.
 * Change a budget here and the validator, the editor autocomplete and the
 * renderer all move together.
 *
 * TWO THINGS ARE ENFORCED BY THE SHAPE OF THIS FILE, NOT BY INSTRUCTION:
 *
 * 1. There is NO `bullets` field. Anywhere. "No bullet points" is not a
 *    request a model may or may not honor. There is nowhere to put a
 *    bullet list. Do not add one. `steps` is the deliberate, capped
 *    escape hatch below and it is a different thing.
 *
 * 2. Branding is a RENDERER SLOT. No slide type has a logo, footer or
 *    color field, so no deck can put the mark in the wrong place or
 *    recolor it. `render.mjs` fills the branding zone from brand tokens
 *    on every slide.
 *
 * CHARACTER BUDGETS ARE DERIVED FROM THE SLIDE BOX, NOT CHOSEN.
 * The stage is 1280x720 with 64px side padding, so the content box is
 * 1152px wide. A line holds about 1152 / (advance * size) characters,
 * where `advance` is the face's mean advance width per character.
 *
 * MEASURED, not assumed. Averaged over a prose sample from the shipped
 * woff2 in brand/fonts:
 *
 *   Fraunces 700 (display type)   0.5196 em/char
 *   IBM Plex Sans 400 (body)      0.4704 em/char
 *
 * The budgets below were originally derived against 0.52 em/char. The
 * display face lands within 0.1% of that, so every budget on a heading
 * still holds exactly; Plex is ~9% narrower, so body fields now carry
 * slack rather than risk. That is why the move to Fraunces and Plex
 * changed no budget in this file.
 *
 *   size    chars/line   used by
 *   80px       27        title
 *   60px       36        statement idea, quote
 *   46px       48        promise, compare panel, final words
 *   34px       65        subtitle, roadmap stop, contributions entry
 *
 * The budget is then chars/line * the number of lines the layout leaves
 * once the branding zone (40px up from the bottom) is subtracted. THE
 * FONT SIZE IS THE INVARIANT AND THE TEXT IS THE VARIABLE: a slide that
 * overruns is a text problem, never a reason to shrink the type.
 *
 * If the typefaces in brand/tokens.json are ever swapped, re-measure.
 * A face wider than 0.52 em/char silently overruns every heading here.
 */

/** Winston, How to Speak §5. A deck may never end on these. */
export const FORBIDDEN_FINAL_WORDS = [
	'thank you',
	'thanks',
	'any questions',
	'questions?',
	'q&a',
];

/*
 * Field kinds the validator understands:
 *   text   { max }                 a single string, inline marks allowed
 *   list   { min, max, item }      a bounded list of fields
 *   asset  {}                      a path, relative to the deck folder
 *   url    {}                      an http(s) link
 *   panel  { fields }              a nested object
 *   notes  {}                      speaker notes, unbounded, never rendered
 *                                  onto the slide itself
 */
const text = (max, doc) => ({ kind: 'text', max, doc });
const asset = () => ({ kind: 'asset' });
const list = (min, max, item) => ({ kind: 'list', min, max, item });
const panel = (fields) => ({ kind: 'panel', fields });

/*
 * A visual always carries its own alt text. Paired here rather than
 * checked afterwards, so `visual` without `visual_alt` is a field the
 * spec simply does not describe.
 */
const VISUAL = {
	visual: asset(),
	visual_alt: text(160),
};

/** Slides that open and close every deck. One of each, in this order. */
export const SPINE = {
	title: {
		doc: 'Opening slide. Full logo lives here.',
		required: ['title'],
		fields: {
			title: text(60),
			subtitle: text(90),
			presenter: text(60, 'The speaker name.'),
			/*
			 * The audience kept landing here. A prompt says "for a
			 * chamber of commerce", which names who is in the ROOM, and
			 * a field labelled only "Venue, date" is the nearest empty
			 * slot for it. Naming the trap in the field description is
			 * cheaper than catching it afterwards.
			 */
			context: text(
				60,
				'Venue and date, e.g. "Charlotte Chamber, March 4". ' +
					'ONLY when the user gave one. Never invent a venue or a ' +
					'date, and never put the audience here. Omit the field ' +
					'if you were not told.',
			),
		},
	},

	/*
	 * Winston's checklist says the Empowerment Promise must land by
	 * slide 3. Because the spine is named fields rather than an array
	 * of typed slides, the promise is ALWAYS slide 2. The rule is not
	 * validated because it cannot be broken.
	 */
	promise: {
		doc: 'The Empowerment Promise. What they can DO when they leave.',
		required: ['promise'],
		fields: {
			kicker: text(40),
			promise: text(200),
		},
	},

	roadmap: {
		doc: 'The outline. Where this talk is going.',
		required: ['stops'],
		fields: {
			label: text(60),
			stops: list(2, 6, text(65)),
		},
	},

	contributions: {
		doc: 'Winston §5. What you gave them, and what they can now do.',
		required: ['gave', 'can_now_do'],
		fields: {
			gave: list(2, 4, text(65)),
			can_now_do: list(2, 4, text(65)),
		},
	},

	/*
	 * No `qr` field. The QR is a brand asset, not a deck decision, so
	 * it lives in brand/tokens.json and the renderer puts it on every
	 * deck's closing slide. Same reason there is no logo field.
	 */
	final: {
		doc: 'Final words. A statement or a CTA tied back to the promise.',
		required: ['words'],
		fields: {
			words: text(140),
			cta: text(60),
		},
	},
};

/** Body slide types. `deck.slides` is a list of these. */
export const BODY = {
	/*
	 * `support` is ONE line, and it is optional. Winston's "minimal
	 * text" is about the room reading instead of listening, not about
	 * leaving the slide bare: a headline alone in the middle of a wall
	 * reads as unfinished. One clarifying line under the idea is the
	 * whole allowance. It is a single string, so it cannot become a
	 * list, and it renders smaller and quieter than the idea so it can
	 * never compete with it.
	 */
	statement: {
		doc: 'ONE big idea, set large, with an optional line under it.',
		required: ['idea'],
		fields: {
			idea: text(110),
			support: text(
				150,
				'One optional line under the idea. A concrete example, a ' +
					'consequence, or the "so what". Never a second idea, ' +
					'never a list.',
			),
			...VISUAL,
		},
	},

	split: {
		doc: 'One idea beside one visual.',
		required: ['idea', 'visual', 'visual_alt'],
		fields: { idea: text(90), support: text(150), ...VISUAL },
	},

	visual: {
		doc: 'The visual IS the slide. Caption is optional and small.',
		required: ['visual', 'visual_alt'],
		fields: { ...VISUAL, caption: text(80) },
	},

	compare: {
		doc: 'Two panels. Before/after, or this-versus-that.',
		required: ['left', 'right'],
		fields: {
			label: text(60),
			left: panel({ label: text(24), idea: text(90) }),
			right: panel({ label: text(24), idea: text(90) }),
		},
	},

	quote: {
		doc: 'A quotation and who said it.',
		required: ['quote'],
		fields: { quote: text(200), attribution: text(60) },
	},

	metric: {
		doc: 'One number, set very large, and what it means.',
		required: ['value', 'label'],
		fields: { value: text(8), label: text(50), context: text(90) },
	},

	/*
	 * THE ONE ESCAPE HATCH, AND WHY IT IS NOT BULLETS.
	 * Winston bans bullet points but explicitly endorses ENUMERATION
	 * ("number things clearly"). The difference is not punctuation, it
	 * is count: three numbered phrases set at 46px read as a structure
	 * the room can hold, and seven read as a document on a wall. The
	 * cap is the whole point. Do not raise it.
	 */
	steps: {
		doc: 'At most THREE numbered phrases. Not a bullet list.',
		required: ['steps'],
		fields: { label: text(60), steps: list(2, 3, text(60)) },
	},

	demo: {
		doc: 'A live demo marker. Put what you actually do in `notes`.',
		required: ['label'],
		fields: {
			label: text(50),
			detail: text(90),
			...VISUAL,
		},
	},

	section: {
		doc: 'A divider. Announces the next movement of the talk.',
		required: ['label'],
		fields: { label: text(60), sub: text(80) },
	},
};

/** Every slide, spine or body, may carry speaker notes. */
export const UNIVERSAL_FIELDS = { notes: { kind: 'notes' } };

export const BODY_TYPES = Object.keys(BODY);
export const SPINE_ORDER = ['title', 'promise', 'roadmap'];
export const SPINE_CLOSE = ['contributions', 'final'];
