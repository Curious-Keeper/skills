/*
 * Rebrand this skill and package it as a new one.
 *
 *   node tools/rebrand.mjs <brand.json> --out <writable dir>
 *
 * The skill folder is read only inside claude.ai, so this never edits
 * itself. It copies the whole skill into <out>, swaps the brand, proves
 * the result by building a sample deck with the copied engine, and
 * zips it. What comes out is <out>/<name>.zip to upload and
 * <out>/<name>-preview.html to look at first.
 *
 * Typefaces are locked. The character budgets in engine/spec.mjs are
 * derived from the advance widths of the shipped faces, so a font swap
 * would pass validation and still overrun every heading. A brand file
 * that mentions fonts is refused rather than half-applied.
 */

import {
	chmodSync,
	copyFileSync,
	cpSync,
	existsSync,
	mkdirSync,
	mkdtempSync,
	readdirSync,
	readFileSync,
	rmSync,
	statSync,
	writeFileSync,
} from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { extname, join, resolve } from 'node:path';
import { derivePalette } from './palette.mjs';
import { zipFolder } from './zip.mjs';

const SKILL = new URL('..', import.meta.url).pathname;
const ALLOWED = ['org', 'url', 'colors', 'logo', 'logo_alt', 'qr', 'qr_alt', 'qr_label', 'voice'];
const QR_TYPES = ['.png', '.jpg', '.jpeg', '.webp', '.svg'];

function fail(msg) {
	console.error(`\n✗ ${msg}\n`);
	process.exit(1);
}

function readSpec(path) {
	if (!existsSync(path)) fail(`no brand file at ${path}`);
	const spec = JSON.parse(readFileSync(path, 'utf8'));
	const keys = Object.keys(spec);

	const locked = keys.filter((k) => /font|typeface/i.test(k));
	if (locked.length) {
		fail(
			`typefaces are locked in this kit (${locked.join(', ')}). The ` +
				'slide text budgets are measured against the shipped fonts; ' +
				'a different face overruns them. Remove the font fields.',
		);
	}
	const unknown = keys.filter((k) => !ALLOWED.includes(k));
	if (unknown.length) fail(`unknown fields: ${unknown.join(', ')}. Allowed: ${ALLOWED.join(', ')}`);

	for (const k of ['org', 'url']) if (!spec[k]?.trim()) fail(`"${k}" is required`);
	if (!spec.colors?.accent) fail('"colors.accent" is required: the main brand color as #rrggbb');
	if (spec.qr && !spec.qr_alt) fail('"qr_alt" is required with a QR: say where the code goes');

	for (const k of ['logo', 'qr']) {
		if (spec[k] && !existsSync(spec[k])) fail(`"${k}" points at ${spec[k]}, which does not exist`);
	}
	if (spec.logo) spec.logo_color = logoColor(spec.logo);
	if (spec.qr && !QR_TYPES.includes(extname(spec.qr).toLowerCase())) {
		fail(`the QR must be one of ${QR_TYPES.join(' ')}, got ${extname(spec.qr)}`);
	}
	return spec;
}

/** "Acme Plumbing & Heat" -> "acme-plumbing-heat-decks" */
function skillName(org) {
	const base = org
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, '-')
		.replace(/^-+|-+$/g, '')
		.slice(0, 50);
	if (!base) fail(`cannot make a skill name from org "${org}"`);
	return `${base}-decks`;
}

/*
 * The renderer tints the logo per surface by replacing ONE named color,
 * so the artwork must be a single-color SVG. Anything else is refused
 * here, with the reason, instead of failing inside the engine later.
 */
function logoColor(path) {
	if (extname(path).toLowerCase() !== '.svg') {
		fail(
			`the logo must be an SVG, got ${extname(path) || 'no extension'}. ` +
				'Leave "logo" out to use the org name as a wordmark instead.',
		);
	}
	const svg = readFileSync(path, 'utf8');
	const paint = /(?:fill|stroke|stop-color)\s*[:=]\s*["']?\s*([^"';\s>]+)/gi;
	const values = [...svg.matchAll(paint)].map((m) => m[1].toLowerCase());
	const ignored = ['none', 'transparent', 'currentcolor'];
	const colors = new Set(values.filter((v) => !ignored.includes(v)));

	const notHex = [...colors].filter((c) => !/^#[0-9a-f]{3}([0-9a-f]{3})?$/.test(c));
	if (notHex.length) {
		fail(
			`the logo paints with ${notHex.join(', ')}. It needs a plain ` +
				'#hex fill (no named colors, gradients or patterns).',
		);
	}
	if (colors.size !== 1) {
		fail(
			`the logo uses ${colors.size} colors (${[...colors].join(', ') || 'none set'}). ` +
				'This engine needs a single-color mark on a transparent ' +
				'background so it can recolor it for light and dark slides. ' +
				'Leave "logo" out to use the org name as a wordmark instead.',
		);
	}
	return [...colors][0];
}

/* The skill folder is mounted read only and cpSync keeps file modes,
 * so the copy has to be made writable before the brand can change. */
function makeWritable(path) {
	chmodSync(path, statSync(path).mode | 0o200);
	if (statSync(path).isDirectory()) {
		for (const name of readdirSync(path)) makeWritable(join(path, name));
	}
}

function writeBrand(dir, spec, palette) {
	const brandDir = join(dir, 'brand');
	const tokensPath = join(brandDir, 'tokens.json');
	const tokens = JSON.parse(readFileSync(tokensPath, 'utf8'));

	for (const old of [tokens.logo_primary, tokens.qr]) {
		if (old) rmSync(join(brandDir, old), { force: true });
	}
	for (const k of ['logo_primary', 'logo_alt', 'logo_source_color', 'qr', 'qr_alt', 'qr_label']) {
		delete tokens[k];
	}

	tokens.org_display_name = spec.org.trim();
	tokens.url = spec.url.trim();
	tokens.palette = palette;

	if (spec.logo) {
		tokens.logo_primary = 'logo.svg';
		/* A logo's alt text is the name of the org it stands for. */
		tokens.logo_alt = spec.logo_alt ?? spec.org.trim();
		tokens.logo_source_color = spec.logo_color;
		copyFileSync(spec.logo, join(brandDir, 'logo.svg'));
	}
	if (spec.qr) {
		tokens.qr = `qr${extname(spec.qr).toLowerCase()}`;
		tokens.qr_alt = spec.qr_alt;
		if (spec.qr_label) tokens.qr_label = spec.qr_label;
		copyFileSync(spec.qr, join(brandDir, tokens.qr));
	}

	writeFileSync(tokensPath, `${JSON.stringify(tokens, null, 2)}\n`);
}

function writeSkillMd(dir, name, spec) {
	const path = join(dir, 'SKILL.md');
	let md = readFileSync(path, 'utf8');
	md = md.replace(/^name: .*$/m, `name: ${name}`);
	md = md.replace(
		/^description: .*$/m,
		`description: Build a presentation deck in the ${spec.org.trim()} house style ` +
			'as a polished, self-contained HTML file. Use whenever someone asks for ' +
			'a deck, slides, a talk, a presentation, or asks to change slides in one ' +
			'they already made, or asks to change its brand. Produces a single ' +
			'.html they download and present, ' +
			'with speaker notes and a presenter view.',
	);
	if (spec.voice?.trim()) {
		const block = /<!-- voice:start -->[\s\S]*?<!-- voice:end -->/;
		if (!block.test(md)) fail('SKILL.md has no voice markers to replace');
		md = md.replace(block, `<!-- voice:start -->\n${spec.voice.trim()}\n<!-- voice:end -->`);
	}
	writeFileSync(path, md);
}

/* Build the sample deck with the COPIED engine, so the preview proves
 * the exact package being handed over. */
function buildPreview(dir, out, name) {
	const work = join(mkdtempSync(join(tmpdir(), 'rebrand-')), `${name}-preview`);
	mkdirSync(work);
	copyFileSync(join(dir, 'reference', 'sample-deck.json'), join(work, 'deck.json'));
	execFileSync('node', [join(dir, 'engine', 'build.mjs'), join(work, 'deck.json'), '--standalone'], {
		stdio: 'inherit',
	});
	const preview = join(out, `${name}-preview.html`);
	copyFileSync(join(work, `${name}-preview.html`), preview);
	rmSync(join(work, '..'), { recursive: true, force: true });
	return preview;
}

const [specArg] = process.argv.slice(2);
const outIdx = process.argv.indexOf('--out');
if (!specArg || outIdx < 0 || !process.argv[outIdx + 1]) {
	fail('usage: node tools/rebrand.mjs <brand.json> --out <writable dir>');
}

const spec = readSpec(resolve(specArg));
const out = resolve(process.argv[outIdx + 1]);
const name = skillName(spec.org);
const stage = join(out, name);

let derived;
try {
	derived = derivePalette(spec.colors);
} catch (e) {
	fail(e.message);
}

mkdirSync(out, { recursive: true });
if (existsSync(stage)) makeWritable(stage);
rmSync(stage, { recursive: true, force: true });
cpSync(SKILL, stage, { recursive: true });
makeWritable(stage);
writeBrand(stage, spec, derived.palette);
writeSkillMd(stage, name, spec);

let preview;
try {
	preview = buildPreview(stage, out, name);
} catch {
	rmSync(stage, { recursive: true, force: true });
	fail('the rebranded engine did not build the sample deck. See the error above.');
}

const zip = join(out, `${name}.zip`);
zipFolder(stage, zip);
rmSync(stage, { recursive: true, force: true });

console.log(`\n✓ ${zip}`);
console.log(`✓ ${preview}`);
console.log(`  skill name: ${name}`);
console.log(`  logo: ${spec.logo ? 'logo.svg' : 'none, the org name is the wordmark'}`);
console.log(`  qr: ${spec.qr ? 'yes' : 'none, the closing slide has no QR'}`);
for (const a of derived.adjusted) console.log(`  adjusted: ${a}`);
