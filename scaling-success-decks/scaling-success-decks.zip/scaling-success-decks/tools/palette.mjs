/*
 * Derive every palette role from one or two brand colors.
 *
 * Nobody arrives at a workshop with thirteen contrast-checked hex
 * values. They arrive with "our blue" and maybe a dark color. Every
 * other role is derived from the brand color's hue, and the two colors
 * they did give are moved only as far as WCAG AA requires.
 *
 * The derivation is deterministic: the same inputs always produce the
 * same palette, which is the whole point of the method being taught.
 * The final word still belongs to the engine's own audit.
 */

import { auditPalette, parseHex, ratio } from '../engine/contrast.mjs';

function toHsl(hex) {
	const [r, g, b] = parseHex(hex).map((v) => v / 255);
	const max = Math.max(r, g, b);
	const min = Math.min(r, g, b);
	const l = (max + min) / 2;
	if (max === min) return [0, 0, l];
	const d = max - min;
	const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
	const h =
		max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
	return [h * 60, s, l];
}

function hsl(h, s, l) {
	const k = (n) => (n + h / 30) % 12;
	const a = s * Math.min(l, 1 - l);
	const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
	const hex = (v) =>
		Math.round(v * 255)
			.toString(16)
			.padStart(2, '0');
	return `#${hex(f(0))}${hex(f(8))}${hex(f(4))}`;
}

/**
 * Walk a color's lightness toward black or white until it clears every
 * [otherColor, minRatio] constraint. Throws if it never does.
 */
function fit(hex, direction, constraints, role) {
	const passes = (c) => constraints.every(([other, min]) => ratio(c, other) >= min);
	if (passes(hex)) return hex.toLowerCase();
	const [h, s, l0] = toHsl(hex);
	const step = direction === 'darker' ? -0.005 : 0.005;
	for (let l = l0; l >= 0 && l <= 1; l += step) {
		const candidate = hsl(h, s, l);
		if (passes(candidate)) return candidate;
	}
	throw new Error(
		`could not make "${role}" from ${hex} readable by moving it ` +
			`${direction}. Pick a different color for it.`,
	);
}

const AA = 4.5;

/**
 * { accent, night? } -> { palette, adjusted }
 *
 * `adjusted` lists every color the user supplied that had to move to
 * pass contrast, so the change can be reported rather than made quietly.
 */
export function derivePalette({ accent, night }) {
	if (!accent) throw new Error('colors.accent is required');
	const [h, s, l] = toHsl(accent);
	const t = Math.min(s, 0.3);

	const surface = hsl(h, t * 0.6, 0.97);
	const accent_ink = hsl(h, t * 0.6, 0.985);
	const night_ink = hsl(h, t * 0.6, 0.97);

	const p = {
		surface,
		panel: hsl(h, t * 0.6, 0.93),
		ink: hsl(h, t * 0.6, 0.1),
		muted: fit(hsl(h, t * 0.3, 0.42), 'darker', [[surface, AA]], 'muted'),
		accent: fit(accent, 'darker', [[surface, AA], [accent_ink, AA]], 'accent'),
		accent_ink,
		rule: hsl(h, t * 0.5, 0.85),
		night: fit(night ?? hsl(h, t * 0.6, 0.07), 'darker', [[night_ink, AA]], 'night'),
		night_ink,
	};
	p.branding_zone_ink = p.muted;

	const [nh, ns, nl] = toHsl(p.night);
	p.night_muted = fit(hsl(nh, ns * 0.5, 0.72), 'lighter', [[p.night, AA]], 'night_muted');
	/* Start night's accent lighter than the brand color. One that only
	 * just clears AA on a dark ground reads as mud from the back row. */
	const nightAccent = hsl(h, s, Math.max(l, 0.65));
	p.night_accent = fit(nightAccent, 'lighter', [[p.night, AA]], 'night_accent');
	p.night_rule = hsl(nh, ns, Math.min(nl + 0.1, 1));

	const adjusted = [];
	if (p.accent !== accent.toLowerCase()) {
		adjusted.push(`accent ${accent} -> ${p.accent} (darkened to read on the light surface)`);
	}
	if (night && p.night !== night.toLowerCase()) {
		adjusted.push(`night ${night} -> ${p.night} (darkened so light text reads on it)`);
	}

	const failures = auditPalette(p);
	if (failures.length) {
		throw new Error(`derived palette failed the audit:\n  - ${failures.join('\n  - ')}`);
	}
	return { palette: p, adjusted };
}
