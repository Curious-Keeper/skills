/*
 * A minimal zip writer. Deflate, no encryption, no zip64.
 *
 * The rebrand step runs inside claude.ai, where nobody can promise a
 * `zip` binary. Node's zlib is always there, so the archive format is
 * written by hand rather than depending on the container.
 */

import { deflateRawSync } from 'node:zlib';
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const CRC_TABLE = Array.from({ length: 256 }, (_, n) => {
	let c = n;
	for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
	return c >>> 0;
});

function crc32(buf) {
	let c = 0xffffffff;
	for (const byte of buf) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
	return (c ^ 0xffffffff) >>> 0;
}

function walk(dir) {
	return readdirSync(dir).flatMap((name) => {
		const path = join(dir, name);
		return statSync(path).isDirectory() ? walk(path) : [path];
	});
}

/* 1980-01-01 00:00. Fixed, so the same input always zips byte for byte. */
const DOS_TIME = 0;
const DOS_DATE = (0 << 9) | (1 << 5) | 1;

function localHeader(name, crc, packed, size) {
	const h = Buffer.alloc(30);
	h.writeUInt32LE(0x04034b50, 0);
	h.writeUInt16LE(20, 4);
	h.writeUInt16LE(0x0800, 6); /* UTF-8 names */
	h.writeUInt16LE(8, 8); /* deflate */
	h.writeUInt16LE(DOS_TIME, 10);
	h.writeUInt16LE(DOS_DATE, 12);
	h.writeUInt32LE(crc, 14);
	h.writeUInt32LE(packed, 18);
	h.writeUInt32LE(size, 22);
	h.writeUInt16LE(name.length, 26);
	return Buffer.concat([h, name]);
}

function centralHeader(name, crc, packed, size, offset) {
	const h = Buffer.alloc(46);
	h.writeUInt32LE(0x02014b50, 0);
	h.writeUInt16LE(20, 4);
	h.writeUInt16LE(20, 6);
	h.writeUInt16LE(0x0800, 8);
	h.writeUInt16LE(8, 10);
	h.writeUInt16LE(DOS_TIME, 12);
	h.writeUInt16LE(DOS_DATE, 14);
	h.writeUInt32LE(crc, 16);
	h.writeUInt32LE(packed, 20);
	h.writeUInt32LE(size, 24);
	h.writeUInt16LE(name.length, 28);
	h.writeUInt32LE(offset, 42);
	return Buffer.concat([h, name]);
}

/**
 * Zip `folder` into `out`, keeping the folder itself as the top-level
 * entry, which is the layout claude.ai expects for a skill.
 */
export function zipFolder(folder, out) {
	const base = join(folder, '..');
	const locals = [];
	const centrals = [];
	let offset = 0;

	for (const file of walk(folder).sort()) {
		const name = Buffer.from(relative(base, file).split(sep).join('/'));
		const data = readFileSync(file);
		const packed = deflateRawSync(data);
		const crc = crc32(data);
		const local = localHeader(name, crc, packed.length, data.length);
		locals.push(local, packed);
		centrals.push(centralHeader(name, crc, packed.length, data.length, offset));
		offset += local.length + packed.length;
	}

	const dir = Buffer.concat(centrals);
	const end = Buffer.alloc(22);
	end.writeUInt32LE(0x06054b50, 0);
	end.writeUInt16LE(centrals.length, 8);
	end.writeUInt16LE(centrals.length, 10);
	end.writeUInt32LE(dir.length, 12);
	end.writeUInt32LE(offset, 16);

	writeFileSync(out, Buffer.concat([...locals, dir, end]));
}
